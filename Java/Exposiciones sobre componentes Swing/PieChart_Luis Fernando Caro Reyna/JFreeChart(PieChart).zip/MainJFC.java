import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.data.general.*;

public class MainJFC {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Colored Trails");
        frame.setTitle("Ejemplo de PieChart");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		DefaultPieDataset datasetA = new DefaultPieDataset();
        
        datasetA.setValue("9-10", 5);
        datasetA.setValue("8-9", 10);
        datasetA.setValue("7-8", 6);
        datasetA.setValue("6-7", 2);

        JFreeChart chart = ChartFactory.createPieChart(
            "Calificaciones de los alumnos de IA", // Nombre de la grafica
            datasetA, // Set de datos
            true, // leyenda
            true, // tooltips
            false // urls
        );

        ChartPanel chartPanel = new ChartPanel(chart);

        frame.add(chartPanel);

		frame.pack();
		frame.setVisible(true);
	}

}
